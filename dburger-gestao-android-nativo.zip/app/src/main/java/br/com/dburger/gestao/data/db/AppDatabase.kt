package br.com.dburger.gestao.data.db

import android.content.Context
import androidx.room.*
import br.com.dburger.gestao.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface InsumoDao {
    @Query("SELECT * FROM insumos WHERE ativo = 1 ORDER BY nome ASC")
    fun listarInsumosAtivos(): Flow<List<InsumoEntity>>

    @Query("SELECT * FROM insumos WHERE id = :id")
    suspend fun buscarPorId(id: String): InsumoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun salvarInsumo(insumo: InsumoEntity)

    @Update
    suspend fun atualizarInsumo(insumo: InsumoEntity)
}

@Dao
interface ProdutoDao {
    @Query("SELECT * FROM produtos WHERE ativo = 1 ORDER BY categoria ASC, nome ASC")
    fun listarProdutosAtivos(): Flow<List<ProdutoEntity>>

    @Query("SELECT * FROM itens_ficha_tecnica WHERE produtoId = :produtoId")
    suspend fun listarItensFicha(produtoId: String): List<ItemFichaEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun salvarProduto(produto: ProdutoEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun salvarItensFicha(itens: List<ItemFichaEntity>)
}

@Dao
interface EstoqueDao {
    @Insert
    suspend fun registrarMovimentacao(mov: MovimentacaoEstoqueEntity)

    @Query("SELECT * FROM movimentacoes_estoque ORDER BY dataHora DESC LIMIT 100")
    fun listarUltimasMovimentacoes(): Flow<List<MovimentacaoEstoqueEntity>>
}

@Dao
interface VendaDao {
    @Query("SELECT * FROM pedidos_venda ORDER BY numeroPedido DESC")
    fun listarPedidos(): Flow<List<PedidoVendaEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun salvarPedido(pedido: PedidoVendaEntity)
}

@Dao
interface CaixaDao {
    @Query("SELECT * FROM lancamentos_caixa ORDER BY dataHora DESC")
    fun listarLancamentos(): Flow<List<LancamentoCaixaEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun salvarLancamento(lancamento: LancamentoCaixaEntity)
}

@Database(
    entities = [
        InsumoEntity::class,
        CompraEntity::class,
        ItemCompraEntity::class,
        ProdutoEntity::class,
        ItemFichaEntity::class,
        MovimentacaoEstoqueEntity::class,
        PedidoVendaEntity::class,
        LancamentoCaixaEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun insumoDao(): InsumoDao
    abstract fun produtoDao(): ProdutoDao
    abstract fun estoqueDao(): EstoqueDao
    abstract fun vendaDao(): VendaDao
    abstract fun caixaDao(): CaixaDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "dburger_gestao.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
