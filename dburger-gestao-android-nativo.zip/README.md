# D’ Burger Gestão — Aplicativo Android Oficial

Aplicativo de gestão financeira e operacional completo para hamburguerias artesanais.
Versão Android nativa empacotada com o **mesmo código de alta fidelidade do Preview**:
- 100% Offline (Armazenamento permanente local no dispositivo com LocalStorage nativo)
- Painel Geral com Faturamento Bruto em destaque, CMV, Reserva Operacional (12,1%) e Lucro Líquido
- Cardápio & Fichas Técnicas detalhadas (com botão de Lixeira em cada lanche para remover exemplos)
- Insumos & Ingredientes com unidades de consumo (com botão de Lixeira em cada insumo)
- Ponto de Venda (PDV) com baixa automática de estoque
- Controle de Compras com notas fiscais e recálculo de CMP
- Fluxo de Caixa dividido nas 3 gavetas financeiras com botão **"Zerar Caixa (R$ 0,00)"** e exclusão individual
- Configurações com opções de **"Zerar Apenas Caixa & Vendas (Manter Meus Insumos e Cardápio)"** ou **"Iniciar Banco Vazio (Apagar Tudo)"**

## 📱 Como Gerar e Instalar o Arquivo APK no Celular

### Opção 1: Pelo GitHub Actions (Sem Computador)
1. Crie um repositório no GitHub (ex: `dburguer-oficial`).
2. Envie os arquivos descompactados deste projeto para o repositório.
3. O GitHub Actions executará o fluxo de compilação automaticamente (leva cerca de 1 minuto).
4. Na aba **Actions**, toque na compilação concluída e baixe o artefato **dburger-gestao-apk**.
5. **IMPORTANTE para evitar conflito:** Desinstale qualquer versão de teste anterior do aplicativo no seu celular (segure o ícone e toque em Desinstalar) antes de instalar o novo APK!
6. Toque no novo APK baixado e instale normalmente!

### Opção 2: Pelo Android Studio no Computador
1. Abra o Android Studio e selecione **Open**.
2. Abra a pasta deste projeto.
3. Aguarde a sincronização e clique em **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
4. O APK estará disponível em `app/build/outputs/apk/debug/app-debug.apk`.
