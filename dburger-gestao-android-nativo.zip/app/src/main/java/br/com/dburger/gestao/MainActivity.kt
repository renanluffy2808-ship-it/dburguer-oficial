package br.com.dburger.gestao

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import br.com.dburger.gestao.ui.theme.DBurgerTheme

// Paleta de Cores Premium Dark & Amber (Identica ao Preview)
val BgCanvas = Color(0xFF09090B)
val CardBg = Color(0xFF18181B)
val CardBorder = Color(0xFF27272A)
val CardSecondary = Color(0xFF202024)
val AmberBrand = Color(0xFFF59E0B)
val GreenFaturamento = Color(0xFF10B981)
val OrangeCmv = Color(0xFFF97316)
val PurpleReserva = Color(0xFFA855F7)
val BlueInfo = Color(0xFF38BDF8)
val RedAlerta = Color(0xFFEF4444)
val TextMuted = Color(0xFFA1A1AA)
val TextDimmed = Color(0xFF71717A)

data class Insumo(
    val id: String,
    val nome: String,
    val categoria: String,
    var estoque: Double,
    val estoqueMinimo: Double,
    val unidade: String,
    val custoUnitario: Double,
    val fornecedor: String = "Fornecedor Padrao"
)

data class ProdutoLanche(
    val id: String,
    val nome: String,
    val categoria: String,
    val preco: Double,
    val cmv: Double,
    val custoEmbalagem: Double = 1.15,
    val descricao: String,
    val ingredientesResumo: String = "Blend Angus, Pao Brioche, Cheddar"
)

data class ItemCarrinho(
    val produto: ProdutoLanche,
    var quantidade: Int
)

data class VendaRegistro(
    val id: String,
    val numero: Int,
    val itensResumo: String,
    val valor: Double,
    val formaPagamento: String,
    val hora: String,
    val data: String = "Hoje"
)

data class CompraNota(
    val id: String,
    val numeroNota: String,
    val fornecedor: String,
    val valorTotal: Double,
    val data: String,
    val itensResumo: String = "Insumos gerais"
)

data class Lancamento(
    val id: String,
    val tipo: String, // ENTRADA ou SAIDA
    val descricao: String,
    val valor: Double,
    val categoria: String,
    val hora: String
)

data class CustoFixo(
    val id: String,
    val nome: String,
    var valor: Double
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DBurgerTheme {
                MainAppScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen() {
    var selectedTab by remember { mutableStateOf(0) }
    var periodoFiltro by remember { mutableStateOf("Hoje") }

    // Insumos reativos com categorias e fornecedores completos
    val insumos = remember {
        mutableStateListOf(
            Insumo("1", "Blend Bovino Angus", "Carnes", 14.5, 5.0, "kg", 38.00, "Frigorifico Boi Forte"),
            Insumo("2", "Pao Brioche Artesanal", "Paes", 48.0, 20.0, "un", 2.20, "Panificadora Central"),
            Insumo("3", "Queijo Cheddar Fatiado", "Queijos", 4.2, 2.0, "kg", 45.00, "Laticinios Vale"),
            Insumo("4", "Bacon em Tiras Defumado", "Carnes", 3.0, 2.5, "kg", 52.00, "Frigorifico Boi Forte"),
            Insumo("5", "Molho Especial D' Burger", "Molhos", 3.5, 1.5, "L", 24.00, "Producao Interna"),
            Insumo("6", "Embalagem Kraft Termica", "Embalagens", 85.0, 30.0, "un", 1.15, "Distribuidora Embalagens"),
            Insumo("7", "Batata Congelada Palito", "Acompanhamentos", 8.0, 4.0, "kg", 14.00, "Congelados Bom Preco"),
            Insumo("8", "Coca-Cola Lata 350ml", "Bebidas", 42.0, 12.0, "un", 2.80, "Distribuidora Bebidas")
        )
    }

    // Cardapio completo com CMV, Embalagem e Margem
    val cardapio = remember {
        mutableStateListOf(
            ProdutoLanche("1", "D' Smash Duplo", "Smash", 28.00, 7.65, 1.15, "2x Smash 80g, 2x Cheddar derretido, Cebola caramelizada e Pao Brioche"),
            ProdutoLanche("2", "D' Artesanal Bacon", "Artesanal", 34.00, 9.85, 1.15, "Blend Angus 160g, Fatias de Bacon crocante, Cheddar e Molho Especial"),
            ProdutoLanche("3", "X-Burguer Tradicional", "Simples", 22.00, 5.75, 1.15, "Blend 120g, Queijo Prato derretido, Maionese verde e Pao Macio"),
            ProdutoLanche("4", "Combo D' Smash + Batata + Refri", "Combos", 44.00, 13.35, 1.15, "Smash Duplo com porcao de Batata Frita palito e Refrigerante lata"),
            ProdutoLanche("5", "Batata Frita Rustica", "Porcoes", 16.00, 4.50, 0.80, "Batata frita crocante temperada com paprica defumada e alecrim")
        )
    }

    // Historico de Vendas reativo
    val vendas = remember {
        mutableStateListOf(
            VendaRegistro("1", 101, "2x D' Smash Duplo", 56.00, "Pix", "19:15"),
            VendaRegistro("2", 102, "1x D' Artesanal Bacon + Refri", 40.00, "Debito", "19:30"),
            VendaRegistro("3", 103, "1x Combo D' Smash", 44.00, "Dinheiro", "19:42"),
            VendaRegistro("4", 104, "3x D' Smash Duplo + 2x Batata", 116.00, "Credito", "20:05"),
            VendaRegistro("5", 105, "1x D' Artesanal Bacon", 34.00, "Pix", "20:18")
        )
    }

    // Lancamentos de Caixa
    val lancamentos = remember {
        mutableStateListOf(
            Lancamento("1", "ENTRADA", "Venda Pedido #101", 56.00, "Venda", "19:15"),
            Lancamento("2", "ENTRADA", "Venda Pedido #102", 40.00, "Venda", "19:30"),
            Lancamento("3", "ENTRADA", "Venda Pedido #103", 44.00, "Venda", "19:42"),
            Lancamento("4", "ENTRADA", "Venda Pedido #104", 116.00, "Venda", "20:05"),
            Lancamento("5", "ENTRADA", "Venda Pedido #105", 34.00, "Venda", "20:18"),
            Lancamento("6", "SAIDA", "Gas de Cozinha Reserva", 110.00, "Despesa Fixa", "17:00")
        )
    }

    // Notas de Compra
    val compras = remember {
        mutableStateListOf(
            CompraNota("1", "NF-4821", "Frigorifico Boi Forte", 550.00, "Ontem", "20kg Carne Blend"),
            CompraNota("2", "NF-1092", "Panificadora Central", 180.00, "Ontem", "80 Paes Brioche"),
            CompraNota("3", "NF-3301", "Distribuidora Embalagens", 115.00, "15/10", "100 Embalagens Kraft")
        )
    }

    // Custos Fixos Detalhados (Identicos ao Preview)
    val custosFixos = remember {
        mutableStateListOf(
            CustoFixo("1", "Aluguel do Ponto", 1200.00),
            CustoFixo("2", "Energia Eletrica", 450.00),
            CustoFixo("3", "Gas de Cozinha", 280.00),
            CustoFixo("4", "Agua e Esgoto", 120.00),
            CustoFixo("5", "Internet e Softwares", 150.00),
            CustoFixo("6", "Honorarios Contador", 200.00)
        )
    }

    // Configuracoes da Hamburgueria
    var configNome by remember { mutableStateOf("D' Burger Gestao") }
    var configTaxaPix by remember { mutableStateOf("0.00") }
    var configTaxaDebito by remember { mutableStateOf("1.20") }
    var configTaxaCredito by remember { mutableStateOf("2.80") }
    var configTaxaVoucher by remember { mutableStateOf("6.50") }
    var configReserva by remember { mutableStateOf("12.10") }
    var configMetaMargem by remember { mutableStateOf("65.00") }
    var configPrevisaoLanches by remember { mutableStateOf("800") }

    // Calculos Dinamicos Baseados no Periodo
    val fatorPeriodo = when (periodoFiltro) {
        "7 Dias" -> 6.8
        "30 Dias" -> 26.5
        else -> 1.0 // Hoje
    }

    val totalVendidoBase = vendas.sumOf { it.valor } * fatorPeriodo
    val totalBurguersBase = (vendas.size * 2 * fatorPeriodo).toInt()
    val totalCmvBase = totalVendidoBase * 0.32
    val totalReservaBase = totalVendidoBase * (configReserva.toDoubleOrNull() ?: 12.10) / 100.0
    val totalTaxasBase = totalVendidoBase * 0.015
    val lucroEstimadoBase = maxOf(0.0, totalVendidoBase - totalCmvBase - totalReservaBase - totalTaxasBase)
    val saldoEmCaixa = lancamentos.sumOf { if (it.tipo == "ENTRADA") it.valor else -it.valor }

    val itensCriticos = insumos.filter { it.estoque <= it.estoqueMinimo }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = CardBg,
                drawerContentColor = Color.White
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = configNome,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = AmberBrand
                    )
                    Text(
                        text = "Hamburgueria Artesanal • Menu Completo",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
                Divider(color = CardBorder)
                Spacer(modifier = Modifier.height(8.dp))

                val menuDrawerItens = listOf(
                    Triple(0, "Painel Geral & Faturamento", Icons.Default.Home),
                    Triple(1, "Insumos & Ingredientes", Icons.Default.Menu),
                    Triple(2, "Cardapio & Fichas Tecnicas", Icons.Default.Star),
                    Triple(3, "Frente de Caixa (PDV)", Icons.Default.Add),
                    Triple(4, "Fluxo de Caixa & Gavetas", Icons.Default.Settings),
                    Triple(5, "Compras & Notas Fiscais", Icons.Default.Check),
                    Triple(6, "Estoque & Reposicao", Icons.Default.Warning),
                    Triple(7, "Relatorios & DRE", Icons.Default.Search),
                    Triple(8, "Configuracoes do Sistema", Icons.Default.Person)
                )

                menuDrawerItens.forEach { (index, titulo, icone) ->
                    NavigationDrawerItem(
                        icon = { Icon(icone, contentDescription = null) },
                        label = { Text(titulo, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) },
                        selected = selectedTab == index,
                        onClick = {
                            selectedTab = index
                            coroutineScope.launch { drawerState.close() }
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = AmberBrand,
                            selectedTextColor = Color.Black,
                            selectedIconColor = Color.Black,
                            unselectedTextColor = Color.White,
                            unselectedIconColor = TextMuted
                        ),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu Lateral", tint = AmberBrand)
                        }
                    },
                    title = {
                        Column {
                            Text(
                                text = configNome,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = AmberBrand
                            )
                            Text(
                                text = "Hamburgueria Artesanal • 100% Offline",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { selectedTab = 8 }) {
                            Icon(Icons.Default.Settings, contentDescription = "Configuracoes", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = CardBg
                    )
                )
            },
            bottomBar = {
                NavigationBar(containerColor = CardBg) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Painel") },
                        label = { Text("Painel", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = AmberBrand,
                            indicatorColor = AmberBrand,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Menu, contentDescription = "Insumos") },
                        label = { Text("Insumos", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = AmberBrand,
                            indicatorColor = AmberBrand,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Star, contentDescription = "Cardapio") },
                        label = { Text("Cardapio", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = AmberBrand,
                            indicatorColor = AmberBrand,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = { Icon(Icons.Default.Add, contentDescription = "PDV") },
                        label = { Text("PDV", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = AmberBrand,
                            indicatorColor = AmberBrand,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 4,
                        onClick = { selectedTab = 4 },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Caixa") },
                        label = { Text("Caixa", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = AmberBrand,
                            indicatorColor = AmberBrand,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize()
                    .background(BgCanvas)
            ) {
                when (selectedTab) {
                    0 -> PainelScreen(
                        periodo = periodoFiltro,
                        onAlterarPeriodo = { periodoFiltro = it },
                        totalVendido = totalVendidoBase,
                        burguersQtd = totalBurguersBase,
                        cmvValor = totalCmvBase,
                        reservaValor = totalReservaBase,
                        lucroReal = lucroEstimadoBase,
                        saldoCaixa = saldoEmCaixa,
                        custosFixosTotal = custosFixos.sumOf { it.valor },
                        itensCriticosQtd = itensCriticos.size,
                        onIrPdv = { selectedTab = 3 },
                        onIrInsumos = { selectedTab = 1 },
                        onIrEstoque = { selectedTab = 6 }
                    )
                    1 -> InsumosScreen(
                        insumos = insumos,
                        onAdicionarInsumo = { insumo -> insumos.add(insumo) },
                        onAlterarEstoque = { id, delta ->
                            val index = insumos.indexOfFirst { it.id == id }
                            if (index != -1) {
                                val item = insumos[index]
                                insumos[index] = item.copy(estoque = maxOf(0.0, item.estoque + delta))
                            }
                        }
                    )
                    2 -> CardapioScreen(
                        cardapio = cardapio,
                        onAdicionarLanche = { lanche -> cardapio.add(lanche) }
                    )
                    3 -> PdvScreen(
                        cardapio = cardapio,
                        insumos = insumos,
                        onFinalizarVenda = { itens, total, forma ->
                            val novoNumero = vendas.size + 101
                            val resumo = itens.joinToString(", ") { "${it.quantidade}x ${it.produto.nome}" }
                            vendas.add(0, VendaRegistro(System.currentTimeMillis().toString(), novoNumero, resumo, total, forma, "Agora"))
                            lancamentos.add(0, Lancamento(System.currentTimeMillis().toString(), "ENTRADA", "Venda Pedido #$novoNumero", total, "Venda", "Agora"))
                            
                            val indexPao = insumos.indexOfFirst { it.categoria == "Paes" }
                            if (indexPao != -1) {
                                insumos[indexPao] = insumos[indexPao].copy(estoque = maxOf(0.0, insumos[indexPao].estoque - itens.sumOf { it.quantidade }))
                            }
                        }
                    )
                    4 -> CaixaScreen(
                        saldoTotal = saldoEmCaixa,
                        cmvAcumulado = totalCmvBase,
                        reservaOperacional = totalReservaBase,
                        lancamentos = lancamentos,
                        onRegistrarLancamento = { tipo, desc, valor, cat ->
                            lancamentos.add(0, Lancamento(System.currentTimeMillis().toString(), tipo, desc, valor, cat, "Hoje"))
                        }
                    )
                    5 -> ComprasScreen(
                        compras = compras,
                        onNovaCompra = { nf, fornecedor, valor ->
                            compras.add(0, CompraNota(System.currentTimeMillis().toString(), nf, fornecedor, valor, "Hoje"))
                            lancamentos.add(0, Lancamento(System.currentTimeMillis().toString(), "SAIDA", "Compra $nf - $fornecedor", valor, "Estoque", "Hoje"))
                        }
                    )
                    6 -> EstoqueScreen(
                        insumos = insumos,
                        onAlterarEstoque = { id, delta ->
                            val index = insumos.indexOfFirst { it.id == id }
                            if (index != -1) {
                                val item = insumos[index]
                                insumos[index] = item.copy(estoque = maxOf(0.0, item.estoque + delta))
                            }
                        }
                    )
                    7 -> RelatoriosScreen(
                        totalVendido = totalVendidoBase,
                        cmvTotal = totalCmvBase,
                        reservaOp = totalReservaBase,
                        qtdLanches = totalBurguersBase,
                        pedidos = vendas
                    )
                    8 -> ConfiguracoesScreen(
                        nomeHamburgueria = configNome,
                        onSalvarNome = { configNome = it },
                        taxaPix = configTaxaPix,
                        onSalvarTaxaPix = { configTaxaPix = it },
                        taxaDebito = configTaxaDebito,
                        onSalvarTaxaDebito = { configTaxaDebito = it },
                        taxaCredito = configTaxaCredito,
                        onSalvarTaxaCredito = { configTaxaCredito = it },
                        taxaVoucher = configTaxaVoucher,
                        onSalvarTaxaVoucher = { configTaxaVoucher = it },
                        reservaOp = configReserva,
                        onSalvarReserva = { configReserva = it },
                        metaMargem = configMetaMargem,
                        onSalvarMetaMargem = { configMetaMargem = it },
                        previsaoLanches = configPrevisaoLanches,
                        onSalvarPrevisaoLanches = { configPrevisaoLanches = it },
                        custosFixos = custosFixos,
                        onAdicionarCustoFixo = { nome, valor -> custosFixos.add(CustoFixo(System.currentTimeMillis().toString(), nome, valor)) },
                        onRemoverCustoFixo = { id -> custosFixos.removeAll { it.id == id } }
                    )
                }
            }
        }
    }
}

// ---------------- 1. PAINEL SCREEN (FATURAMENTO NO TOPO E DESIGN IDENTICO) ----------------

@Composable
fun PainelScreen(
    periodo: String,
    onAlterarPeriodo: (String) -> Unit,
    totalVendido: Double,
    burguersQtd: Int,
    cmvValor: Double,
    reservaValor: Double,
    lucroReal: Double,
    saldoCaixa: Double,
    custosFixosTotal: Double,
    itensCriticosQtd: Int,
    onIrPdv: () -> Unit,
    onIrInsumos: () -> Unit,
    onIrEstoque: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Alerta de Estoque Baixo se houver
        if (itensCriticosQtd > 0) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF450A0A)),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF991B1B))),
                    modifier = Modifier.fillMaxWidth().clickable { onIrEstoque() }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = RedAlerta, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Alerta de Estoque Critico!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("$itensCriticosQtd ingrediente(s) abaixo do estoque minimo.", color = Color(0xFFFCA5A5), fontSize = 11.sp)
                            }
                        }
                        Text("Ver Estoque ->", color = RedAlerta, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Header com Seletor de Periodo (Hoje, 7 Dias, 30 Dias)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Painel Operacional", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("Destinacao real do dinheiro sem ilusao", fontSize = 11.sp, color = TextMuted)
                }

                Row(
                    modifier = Modifier
                        .background(CardBg, RoundedCornerShape(12.dp))
                        .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                        .padding(3.dp)
                ) {
                    listOf("Hoje", "7 Dias", "30 Dias").forEach { opt ->
                        val ativo = periodo == opt
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (ativo) AmberBrand else Color.Transparent)
                                .clickable { onAlterarPeriodo(opt) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = opt,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (ativo) Color.Black else TextMuted
                            )
                        }
                    }
                }
            }
        }

        // CARD #1: FATURAMENTO BRUTO (EM DESTAQUE MAXIMO NO TOPO)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(18.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF059669))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .background(Color(0xFF065F46), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("R$", color = GreenFaturamento, fontWeight = FontWeight.Black, fontSize = 14.sp)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    "FATURAMENTO BRUTO",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = GreenFaturamento,
                                    letterSpacing = 0.5.sp
                                )
                                Text("Total vendido sem deducoes", fontSize = 11.sp, color = TextMuted)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .background(Color(0xFF064E3B), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                "$burguersQtd lanches",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GreenFaturamento
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = String.format(java.util.Locale.US, "R$ %.2f", totalVendido),
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Entrada bruta de todas as vendas e pedidos no periodo",
                        fontSize = 11.sp,
                        color = TextDimmed
                    )
                }
            }
        }

        // 3 CARDS DE DESTINACAO: CMV, RESERVA E LUCRO REAL
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Card 2: Reposicao Insumos (CMV)
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("REPOSICAO (CMV)", fontSize = 10.sp, fontWeight = FontWeight.Black, color = OrangeCmv)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            String.format(java.util.Locale.US, "R$ %.2f", cmvValor),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = OrangeCmv
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("32.0% para recomprar", fontSize = 10.sp, color = TextMuted)
                    }
                }

                // Card 3: Reserva Operacional 12,1%
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("RESERVA OP. (12,1%)", fontSize = 10.sp, fontWeight = FontWeight.Black, color = PurpleReserva)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            String.format(java.util.Locale.US, "R$ %.2f", reservaValor),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = PurpleReserva
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Seguranca e 13o", fontSize = 10.sp, color = TextMuted)
                    }
                }
            }
        }

        item {
            // Card 4: Lucro Real do Dono
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF022C22)),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF059669))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("LUCRO ESTIMADO LIVRE", fontSize = 11.sp, fontWeight = FontWeight.Black, color = GreenFaturamento)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("Resultado real do negocio apos insumos e taxas", fontSize = 10.sp, color = Color(0xFF6EE7B7))
                    }
                    Text(
                        String.format(java.util.Locale.US, "R$ %.2f", lucroReal),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }
        }

        // Card 5: Saldo em Caixa Livre
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("SALDO TOTAL EM CAIXA", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            String.format(java.util.Locale.US, "R$ %.2f", saldoCaixa),
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            color = AmberBrand
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF78350F), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Dinheiro Real", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberBrand)
                    }
                }
            }
        }

        // Botoes de Acao Rapida
        item {
            Button(
                onClick = onIrPdv,
                colors = ButtonDefaults.buttonColors(containerColor = AmberBrand, contentColor = Color.Black),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("ABRIR FRENTE DE CAIXA (PDV)", fontWeight = FontWeight.Black, fontSize = 13.sp)
            }
        }

        item {
            OutlinedButton(
                onClick = onIrInsumos,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Icon(Icons.Default.Menu, contentDescription = null, tint = AmberBrand, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("GERENCIAR INSUMOS E ESTOQUE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        // RANKING DOS MAIS VENDIDOS NA CHAPA
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("LANCHES MAIS VENDIDOS NA CHAPA", fontSize = 11.sp, fontWeight = FontWeight.Black, color = AmberBrand)

                    val ranking = listOf(
                        Triple("1. D' Smash Duplo", "24 vendidos • R$ 672,00", 1.0f),
                        Triple("2. D' Artesanal Bacon", "18 vendidos • R$ 612,00", 0.75f),
                        Triple("3. Combo D' Smash", "12 vendidos • R$ 528,00", 0.50f),
                        Triple("4. Batata Frita Rustica", "15 vendidos • R$ 240,00", 0.62f)
                    )

                    ranking.forEach { (nome, detalhe, progresso) ->
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(nome, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(detalhe, fontSize = 11.sp, color = TextMuted)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = progresso,
                                color = AmberBrand,
                                trackColor = CardSecondary,
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                            )
                        }
                    }
                }
            }
        }

        // PONTO DE EQUILIBRIO (BREAK-EVEN)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("PONTO DE EQUILIBRIO (BREAK-EVEN)", fontSize = 11.sp, fontWeight = FontWeight.Black, color = BlueInfo)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Custos Fixos Mensais: " + String.format(java.util.Locale.US, "R$ %.2f", custosFixosTotal),
                        fontSize = 12.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Meta para empatar e pagar as contas: ~185 lanches/mes", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = 0.68f,
                        color = GreenFaturamento,
                        trackColor = CardSecondary,
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("68% da meta atingida no mes atual", fontSize = 10.sp, color = GreenFaturamento, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------------- 2. INSUMOS SCREEN (CATEGORIAS E ESTOQUE) ----------------

@Composable
fun InsumosScreen(
    insumos: List<Insumo>,
    onAdicionarInsumo: (Insumo) -> Unit,
    onAlterarEstoque: (String, Double) -> Unit
) {
    var categoriaFiltro by remember { mutableStateOf("Todos") }
    var mostrarDialogo by remember { mutableStateOf(false) }
    var nomeNovo by remember { mutableStateOf("") }
    var categoriaNova by remember { mutableStateOf("Carnes") }
    var estoqueNovo by remember { mutableStateOf("10.0") }
    var estoqueMinimoNovo by remember { mutableStateOf("4.0") }
    var unidadeNova by remember { mutableStateOf("kg") }
    var custoNovo by remember { mutableStateOf("38.00") }
    var fornecedorNovo by remember { mutableStateOf("Frigorifico") }

    val categorias = listOf("Todos", "Carnes", "Paes", "Queijos", "Molhos", "Embalagens", "Bebidas", "Acompanhamentos")
    val insumosFiltrados = if (categoriaFiltro == "Todos") insumos else insumos.filter { it.categoria == categoriaFiltro }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Estoque de Insumos", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("Ingredientes, embalagens e precos de custo", fontSize = 11.sp, color = TextMuted)
                }
                Button(
                    onClick = { mostrarDialogo = true },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberBrand, contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Novo", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Filtros de Categoria em Rolagem Horizontal
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(categorias) { cat ->
                    val sel = categoriaFiltro == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (sel) AmberBrand else CardBg)
                            .border(1.dp, if (sel) AmberBrand else CardBorder, RoundedCornerShape(8.dp))
                            .clickable { categoriaFiltro = cat }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = cat,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (sel) Color.Black else TextMuted
                        )
                    }
                }
            }
        }

        items(insumosFiltrados) { item ->
            val statusCor = if (item.estoque <= 0.0) RedAlerta else if (item.estoque <= item.estoqueMinimo) OrangeCmv else GreenFaturamento
            val statusTexto = if (item.estoque <= 0.0) "ZERADO" else if (item.estoque <= item.estoqueMinimo) "BAIXO" else "OK"

            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(item.nome, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .background(statusCor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            ) {
                                Text(statusTexto, color = statusCor, fontSize = 9.sp, fontWeight = FontWeight.Black)
                            }
                        }
                        Text(
                            "${item.categoria} • Custo: R$ " + String.format(java.util.Locale.US, "%.2f", item.custoUnitario) + "/${item.unidade}",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                        Text("Fornecedor: ${item.fornecedor}", fontSize = 10.sp, color = TextDimmed)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { onAlterarEstoque(item.id, -1.0) },
                            modifier = Modifier.size(32.dp).background(CardSecondary, RoundedCornerShape(8.dp))
                        ) {
                            Text("-", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }

                        Text(
                            text = String.format(java.util.Locale.US, "%.1f %s", item.estoque, item.unidade),
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            color = statusCor,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        IconButton(
                            onClick = { onAlterarEstoque(item.id, 1.0) },
                            modifier = Modifier.size(32.dp).background(CardSecondary, RoundedCornerShape(8.dp))
                        ) {
                            Text("+", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }

    if (mostrarDialogo) {
        AlertDialog(
            onDismissRequest = { mostrarDialogo = false },
            title = { Text("Cadastrar Novo Insumo") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = nomeNovo, onValueChange = { nomeNovo = it }, label = { Text("Nome do Insumo") }, singleLine = true)
                    OutlinedTextField(value = estoqueNovo, onValueChange = { estoqueNovo = it }, label = { Text("Estoque Inicial") }, singleLine = true)
                    OutlinedTextField(value = estoqueMinimoNovo, onValueChange = { estoqueMinimoNovo = it }, label = { Text("Estoque Minimo de Alerta") }, singleLine = true)
                    OutlinedTextField(value = custoNovo, onValueChange = { custoNovo = it }, label = { Text("Custo por Unidade (R$)") }, singleLine = true)
                    OutlinedTextField(value = fornecedorNovo, onValueChange = { fornecedorNovo = it }, label = { Text("Fornecedor") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (nomeNovo.isNotBlank()) {
                        val est = estoqueNovo.toDoubleOrNull() ?: 10.0
                        val min = estoqueMinimoNovo.toDoubleOrNull() ?: 3.0
                        val cus = custoNovo.toDoubleOrNull() ?: 20.0
                        onAdicionarInsumo(
                            Insumo(System.currentTimeMillis().toString(), nomeNovo, categoriaNova, est, min, unidadeNova, cus, fornecedorNovo)
                        )
                        mostrarDialogo = false
                        nomeNovo = ""
                    }
                }) {
                    Text("Salvar Insumo")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarDialogo = false }) { Text("Cancelar") }
            }
        )
    }
}

// ---------------- 3. CARDAPIO E FICHAS TECNICAS ----------------

@Composable
fun CardapioScreen(
    cardapio: List<ProdutoLanche>,
    onAdicionarLanche: (ProdutoLanche) -> Unit
) {
    var mostrarModal by remember { mutableStateOf(false) }
    var nomeLanche by remember { mutableStateOf("") }
    var precoLanche by remember { mutableStateOf("32.00") }
    var cmvLanche by remember { mutableStateOf("9.20") }
    var descLanche by remember { mutableStateOf("Blend 160g, Queijo Cheddar e Pao Brioche") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Cardapio & Fichas Tecnicas", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("Engenharia de preco, CMV e margem de contribuicao", fontSize = 11.sp, color = TextMuted)
                }
                Button(
                    onClick = { mostrarModal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberBrand, contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Novo Lanche", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        items(cardapio) { lanche ->
            val custoTotal = lanche.cmv + lanche.custoEmbalagem
            val margemBruta = if (lanche.preco > 0) ((lanche.preco - custoTotal) / lanche.preco) * 100.0 else 0.0
            val statusMargemCor = if (margemBruta >= 60.0) GreenFaturamento else if (margemBruta >= 45.0) AmberBrand else RedAlerta

            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(lanche.nome, fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color.White)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(lanche.descricao, fontSize = 11.sp, color = TextMuted)
                        }
                        Text(
                            String.format(java.util.Locale.US, "R$ %.2f", lanche.preco),
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = AmberBrand
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CardSecondary, RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("CMV Insumos: " + String.format(java.util.Locale.US, "R$ %.2f", lanche.cmv), fontSize = 11.sp, color = OrangeCmv, fontWeight = FontWeight.Bold)
                            Text("Embalagem: " + String.format(java.util.Locale.US, "R$ %.2f", lanche.custoEmbalagem), fontSize = 10.sp, color = TextDimmed)
                        }

                        Box(
                            modifier = Modifier
                                .background(statusMargemCor.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                "Margem: " + String.format(java.util.Locale.US, "%.1f%%", margemBruta),
                                fontSize = 11.sp,
                                color = statusMargemCor,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }
    }

    if (mostrarModal) {
        AlertDialog(
            onDismissRequest = { mostrarModal = false },
            title = { Text("Novo Item no Cardapio") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = nomeLanche, onValueChange = { nomeLanche = it }, label = { Text("Nome do Lanche") }, singleLine = true)
                    OutlinedTextField(value = descLanche, onValueChange = { descLanche = it }, label = { Text("Ingredientes / Descricao") }, singleLine = true)
                    OutlinedTextField(value = precoLanche, onValueChange = { precoLanche = it }, label = { Text("Preco de Venda (R$)") }, singleLine = true)
                    OutlinedTextField(value = cmvLanche, onValueChange = { cmvLanche = it }, label = { Text("Custo Total dos Insumos (R$)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (nomeLanche.isNotBlank()) {
                        val p = precoLanche.toDoubleOrNull() ?: 28.0
                        val c = cmvLanche.toDoubleOrNull() ?: 8.0
                        onAdicionarLanche(
                            ProdutoLanche(System.currentTimeMillis().toString(), nomeLanche, "Artesanal", p, c, 1.15, descLanche)
                        )
                        mostrarModal = false
                        nomeLanche = ""
                    }
                }) {
                    Text("Cadastrar")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModal = false }) { Text("Cancelar") }
            }
        )
    }
}

// ---------------- 4. FRENTE DE CAIXA (PDV RAPIDO) ----------------

@Composable
fun PdvScreen(
    cardapio: List<ProdutoLanche>,
    insumos: List<Insumo>,
    onFinalizarVenda: (List<ItemCarrinho>, Double, String) -> Unit
) {
    val carrinho = remember { mutableStateListOf<ItemCarrinho>() }
    var formaPagamento by remember { mutableStateOf("Pix") }
    var vendaConcluidaMsg by remember { mutableStateOf<String?>(null) }

    val totalPedido = carrinho.sumOf { it.produto.preco * it.quantidade }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Frente de Caixa (PDV)", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("Lanca pedidos, abate insumos e atualiza o Faturamento na hora", fontSize = 11.sp, color = TextMuted)
        }

        if (vendaConcluidaMsg != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF065F46)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = GreenFaturamento)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(vendaConcluidaMsg ?: "", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text("ITENS DO CARDAPIO", fontSize = 11.sp, fontWeight = FontWeight.Black, color = AmberBrand)
        }

        items(cardapio) { lanche ->
            val itemNoCarrinho = carrinho.find { it.produto.id == lanche.id }
            val qtd = itemNoCarrinho?.quantidade ?: 0

            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(lanche.nome, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Text(String.format(java.util.Locale.US, "R$ %.2f", lanche.preco), color = AmberBrand, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (qtd > 0) {
                            IconButton(
                                onClick = {
                                    val index = carrinho.indexOfFirst { it.produto.id == lanche.id }
                                    if (index != -1) {
                                        if (carrinho[index].quantidade > 1) {
                                            carrinho[index] = carrinho[index].copy(quantidade = carrinho[index].quantidade - 1)
                                        } else {
                                            carrinho.removeAt(index)
                                        }
                                    }
                                },
                                modifier = Modifier.size(32.dp).background(CardSecondary, RoundedCornerShape(8.dp))
                            ) {
                                Text("-", color = Color.White, fontWeight = FontWeight.Bold)
                            }

                            Text("$qtd", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                        }

                        Button(
                            onClick = {
                                val index = carrinho.indexOfFirst { it.produto.id == lanche.id }
                                if (index != -1) {
                                    carrinho[index] = carrinho[index].copy(quantidade = carrinho[index].quantidade + 1)
                                } else {
                                    carrinho.add(ItemCarrinho(lanche, 1))
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AmberBrand, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(if (qtd > 0) "+1" else "Adicionar", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (carrinho.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AmberBrand)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("RESUMO DO PEDIDO", fontWeight = FontWeight.Black, fontSize = 12.sp, color = AmberBrand)
                        Spacer(modifier = Modifier.height(8.dp))

                        carrinho.forEach {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${it.quantidade}x ${it.produto.nome}", fontSize = 12.sp, color = Color.White)
                                Text(String.format(java.util.Locale.US, "R$ %.2f", it.produto.preco * it.quantidade), fontSize = 12.sp, color = Color.White)
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 10.dp), color = CardBorder)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("TOTAL A COBRAR:", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                            Text(String.format(java.util.Locale.US, "R$ %.2f", totalPedido), fontWeight = FontWeight.Black, fontSize = 20.sp, color = GreenFaturamento)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Forma de Pagamento:", fontSize = 11.sp, color = TextMuted)
                        Spacer(modifier = Modifier.height(4.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Pix", "Dinheiro", "Debito", "Credito").forEach { forma ->
                                FilterChip(
                                    selected = formaPagamento == forma,
                                    onClick = { formaPagamento = forma },
                                    label = { Text(forma, fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AmberBrand,
                                        selectedLabelColor = Color.Black
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                onFinalizarVenda(carrinho.toList(), totalPedido, formaPagamento)
                                vendaConcluidaMsg = "Pedido de " + String.format(java.util.Locale.US, "R$ %.2f", totalPedido) + " no " + formaPagamento + " gravado com sucesso! Faturamento atualizado."
                                carrinho.clear()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GreenFaturamento, contentColor = Color.Black),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().height(50.dp)
                        ) {
                            Text("CONFIRMAR PEDIDO E BAIXAR ESTOQUE", fontWeight = FontWeight.Black, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

// ---------------- 5. FLUXO DE CAIXA E GAVETAS ----------------

@Composable
fun CaixaScreen(
    saldoTotal: Double,
    cmvAcumulado: Double,
    reservaOperacional: Double,
    lancamentos: List<Lancamento>,
    onRegistrarLancamento: (String, String, Double, String) -> Unit
) {
    var mostrarModalEntrada by remember { mutableStateOf(false) }
    var descLancamento by remember { mutableStateOf("") }
    var valorLancamento by remember { mutableStateOf("") }
    var tipoLancamento by remember { mutableStateOf("SAIDA") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Fluxo de Caixa & Gavetas", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("Separacao inteligente do dinheiro: Insumos, Reserva e Lucro Livre", fontSize = 11.sp, color = TextMuted)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("SALDO TOTAL EM CAIXA", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        String.format(java.util.Locale.US, "R$ %.2f", saldoTotal),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = AmberBrand
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Divider(color = CardBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Divisao das 3 Gavetas Financeiras:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Gaveta 1: Reposicao de Insumos", fontSize = 11.sp, color = TextMuted)
                        Text(String.format(java.util.Locale.US, "R$ %.2f", cmvAcumulado), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OrangeCmv)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Gaveta 2: Reserva Operacional (12,1%)", fontSize = 11.sp, color = TextMuted)
                        Text(String.format(java.util.Locale.US, "R$ %.2f", reservaOperacional), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PurpleReserva)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Gaveta 3: Lucro Livre do Proprietario", fontSize = 11.sp, color = TextMuted)
                        val lucroLivre = maxOf(0.0, saldoTotal - cmvAcumulado - reservaOperacional)
                        Text(String.format(java.util.Locale.US, "R$ %.2f", lucroLivre), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GreenFaturamento)
                    }
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        tipoLancamento = "SAIDA"
                        mostrarModalEntrada = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedAlerta, contentColor = Color.White),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("- Despesa / Sangria", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        tipoLancamento = "ENTRADA"
                        mostrarModalEntrada = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenFaturamento, contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("+ Entrada Caixa", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Text("EXTRATO DE LANCAMENTOS RECENTES", fontSize = 11.sp, fontWeight = FontWeight.Black, color = AmberBrand)
        }

        items(lancamentos) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(item.descricao, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("${item.categoria} • ${item.hora}", fontSize = 11.sp, color = TextMuted)
                    }
                    Text(
                        text = (if (item.tipo == "ENTRADA") "+ " else "- ") + String.format(java.util.Locale.US, "R$ %.2f", item.valor),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (item.tipo == "ENTRADA") GreenFaturamento else RedAlerta
                    )
                }
            }
        }
    }

    if (mostrarModalEntrada) {
        AlertDialog(
            onDismissRequest = { mostrarModalEntrada = false },
            title = { Text(if (tipoLancamento == "ENTRADA") "Adicionar Entrada no Caixa" else "Registrar Despesa / Sangria") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = descLancamento,
                        onValueChange = { descLancamento = it },
                        label = { Text("Descricao (ex: Compra de Queijo, Gas, Retirada)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = valorLancamento,
                        onValueChange = { valorLancamento = it },
                        label = { Text("Valor em Reais (R$)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val v = valorLancamento.toDoubleOrNull() ?: 0.0
                    if (descLancamento.isNotBlank() && v > 0) {
                        onRegistrarLancamento(tipoLancamento, descLancamento, v, if (tipoLancamento == "ENTRADA") "Aporte" else "Despesa")
                        mostrarModalEntrada = false
                        descLancamento = ""
                        valorLancamento = ""
                    }
                }) {
                    Text("Confirmar")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalEntrada = false }) { Text("Cancelar") }
            }
        )
    }
}

// ---------------- 6. COMPRAS E NOTAS FISCAIS ----------------

@Composable
fun ComprasScreen(
    compras: List<CompraNota>,
    onNovaCompra: (String, String, Double) -> Unit
) {
    var mostrarModal by remember { mutableStateOf(false) }
    var nfNovo by remember { mutableStateOf("") }
    var fornecedorNovo by remember { mutableStateOf("") }
    var valorNovo by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Compras & Notas Fiscais", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("Historico de notas e reposicao de insumos", fontSize = 11.sp, color = TextMuted)
                }
                Button(
                    onClick = { mostrarModal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberBrand, contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Nova Nota", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        items(compras) { compra ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(compra.numeroNota, fontWeight = FontWeight.Black, fontSize = 14.sp, color = AmberBrand)
                        Text(compra.fornecedor, fontSize = 12.sp, color = Color.White)
                        Text("Data: ${compra.data} • ${compra.itensResumo}", fontSize = 10.sp, color = TextMuted)
                    }
                    Text(
                        String.format(java.util.Locale.US, "R$ %.2f", compra.valorTotal),
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = GreenFaturamento
                    )
                }
            }
        }
    }

    if (mostrarModal) {
        AlertDialog(
            onDismissRequest = { mostrarModal = false },
            title = { Text("Lancar Nova Compra") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = nfNovo, onValueChange = { nfNovo = it }, label = { Text("Numero da Nota / Cupom") }, singleLine = true)
                    OutlinedTextField(value = fornecedorNovo, onValueChange = { fornecedorNovo = it }, label = { Text("Nome do Fornecedor") }, singleLine = true)
                    OutlinedTextField(value = valorNovo, onValueChange = { valorNovo = it }, label = { Text("Valor Total (R$)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val v = valorNovo.toDoubleOrNull() ?: 0.0
                    if (fornecedorNovo.isNotBlank() && v > 0) {
                        onNovaCompra(if (nfNovo.isBlank()) "Sem Nota" else nfNovo, fornecedorNovo, v)
                        mostrarModal = false
                        nfNovo = ""
                        fornecedorNovo = ""
                        valorNovo = ""
                    }
                }) {
                    Text("Salvar Compra")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModal = false }) { Text("Cancelar") }
            }
        )
    }
}

// ---------------- 7. ESTOQUE E ALERTAS DE REPOSICAO ----------------

@Composable
fun EstoqueScreen(
    insumos: List<Insumo>,
    onAlterarEstoque: (String, Double) -> Unit
) {
    val itensCriticos = insumos.filter { it.estoque <= it.estoqueMinimo }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Estoque & Reposicao", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("Acompanhamento rigoroso de validade e niveis minimos", fontSize = 11.sp, color = TextMuted)
        }

        if (itensCriticos.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFCA5A5))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "${itensCriticos.size} itens necessitam de compra urgente para nao parar a chapa!",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        items(insumos) { item ->
            val statusCor = if (item.estoque <= 0.0) RedAlerta else if (item.estoque <= item.estoqueMinimo) OrangeCmv else GreenFaturamento
            val statusTexto = if (item.estoque <= 0.0) "ZERADO" else if (item.estoque <= item.estoqueMinimo) "CRITICO" else "NORMAL"

            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(item.nome, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .background(statusCor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(statusTexto, fontSize = 9.sp, fontWeight = FontWeight.Black, color = statusCor)
                            }
                        }
                        Text(
                            "Estoque Atual: " + String.format(java.util.Locale.US, "%.1f %s", item.estoque, item.unidade) +
                                    " (Minimo: " + String.format(java.util.Locale.US, "%.1f %s", item.estoqueMinimo, item.unidade) + ")",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }

                    Row {
                        IconButton(
                            onClick = { onAlterarEstoque(item.id, -1.0) },
                            modifier = Modifier.size(32.dp).background(CardSecondary, RoundedCornerShape(8.dp))
                        ) {
                            Text("-", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = { onAlterarEstoque(item.id, 1.0) },
                            modifier = Modifier.size(32.dp).background(CardSecondary, RoundedCornerShape(8.dp))
                        ) {
                            Text("+", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ---------------- 8. RELATORIOS E DRE ----------------

@Composable
fun RelatoriosScreen(
    totalVendido: Double,
    cmvTotal: Double,
    reservaOp: Double,
    qtdLanches: Int,
    pedidos: List<VendaRegistro>
) {
    val lucroLiquido = maxOf(0.0, totalVendido - cmvTotal - reservaOp)
    val ticketMedio = if (pedidos.isNotEmpty()) totalVendido / pedidos.size else 0.0

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Relatorios & DRE Financeiro", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("Demonstrativo de Resultado do Exercicio consolidado", fontSize = 11.sp, color = TextMuted)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("DRE SIMPLIFICADO", fontSize = 11.sp, fontWeight = FontWeight.Black, color = AmberBrand)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("(+) Faturamento Bruto Total:", color = Color.White, fontSize = 13.sp)
                        Text(String.format(java.util.Locale.US, "R$ %.2f", totalVendido), fontWeight = FontWeight.Black, color = GreenFaturamento, fontSize = 13.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("(-) CMV - Reposicao Insumos:", color = Color.White, fontSize = 13.sp)
                        Text(String.format(java.util.Locale.US, "R$ %.2f", cmvTotal), fontWeight = FontWeight.Bold, color = OrangeCmv, fontSize = 13.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("(-) Reserva Operacional (12,1%):", color = Color.White, fontSize = 13.sp)
                        Text(String.format(java.util.Locale.US, "R$ %.2f", reservaOp), fontWeight = FontWeight.Bold, color = PurpleReserva, fontSize = 13.sp)
                    }
                    Divider(color = CardBorder)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("(=) Lucro Liquido Real:", fontWeight = FontWeight.Black, color = Color.White, fontSize = 14.sp)
                        Text(String.format(java.util.Locale.US, "R$ %.2f", lucroLiquido), fontWeight = FontWeight.Black, color = GreenFaturamento, fontSize = 18.sp)
                    }
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("TICKET MEDIO", fontSize = 10.sp, fontWeight = FontWeight.Black, color = BlueInfo)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(String.format(java.util.Locale.US, "R$ %.2f", ticketMedio), fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
                    }
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("PEDIDOS TOTAIS", fontSize = 10.sp, fontWeight = FontWeight.Black, color = AmberBrand)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${pedidos.size} pedidos", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
                    }
                }
            }
        }
    }
}

// ---------------- 9. CONFIGURACOES COMPLETAS (IDENTICAS AO PREVIEW) ----------------

@Composable
fun ConfiguracoesScreen(
    nomeHamburgueria: String,
    onSalvarNome: (String) -> Unit,
    taxaPix: String,
    onSalvarTaxaPix: (String) -> Unit,
    taxaDebito: String,
    onSalvarTaxaDebito: (String) -> Unit,
    taxaCredito: String,
    onSalvarTaxaCredito: (String) -> Unit,
    taxaVoucher: String,
    onSalvarTaxaVoucher: (String) -> Unit,
    reservaOp: String,
    onSalvarReserva: (String) -> Unit,
    metaMargem: String,
    onSalvarMetaMargem: (String) -> Unit,
    previsaoLanches: String,
    onSalvarPrevisaoLanches: (String) -> Unit,
    custosFixos: List<CustoFixo>,
    onAdicionarCustoFixo: (String, Double) -> Unit,
    onRemoverCustoFixo: (String) -> Unit
) {
    var editNome by remember { mutableStateOf(nomeHamburgueria) }
    var editPix by remember { mutableStateOf(taxaPix) }
    var editDeb by remember { mutableStateOf(taxaDebito) }
    var editCred by remember { mutableStateOf(taxaCredito) }
    var editVoucher by remember { mutableStateOf(taxaVoucher) }
    var editRes by remember { mutableStateOf(reservaOp) }
    var editMargem by remember { mutableStateOf(metaMargem) }
    var editPrevisao by remember { mutableStateOf(previsaoLanches) }

    var novoCustoNome by remember { mutableStateOf("") }
    var novoCustoValor by remember { mutableStateOf("") }
    var salvoMsg by remember { mutableStateOf(false) }

    val totalCustosFixos = custosFixos.sumOf { it.valor }
    val lanchesInt = editPrevisao.toIntOrNull() ?: 800
    val rateioPorLanche = if (lanchesInt > 0) totalCustosFixos / lanchesInt else 0.0

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Configuracoes da Hamburgueria", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("Taxas das maquinetas, reserva operacional e custos fixos mensais", fontSize = 11.sp, color = TextMuted)
        }

        if (salvoMsg) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF065F46)), shape = RoundedCornerShape(12.dp)) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = GreenFaturamento)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Todas as configuracoes foram salvas com sucesso!", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // DADOS DO ESTABELECIMENTO
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("DADOS DO ESTABELECIMENTO", fontSize = 11.sp, fontWeight = FontWeight.Black, color = AmberBrand)

                    OutlinedTextField(
                        value = editNome,
                        onValueChange = { editNome = it },
                        label = { Text("Nome da Hamburgueria") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        }

        // TAXAS DE PAGAMENTO DAS MAQUINAS (%)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("TAXAS DAS MAQUINAS DE CARTAO (%)", fontSize = 11.sp, fontWeight = FontWeight.Black, color = AmberBrand)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = editPix,
                            onValueChange = { editPix = it },
                            label = { Text("Pix (%)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = editDeb,
                            onValueChange = { editDeb = it },
                            label = { Text("Debito (%)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = editCred,
                            onValueChange = { editCred = it },
                            label = { Text("Credito (%)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = editVoucher,
                            onValueChange = { editVoucher = it },
                            label = { Text("Voucher VR (%)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
            }
        }

        // PARAMETROS FINANCEIROS (RESERVA E MARGEM)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("PARAMETROS FINANCEIROS E METAS", fontSize = 11.sp, fontWeight = FontWeight.Black, color = PurpleReserva)

                    OutlinedTextField(
                        value = editRes,
                        onValueChange = { editRes = it },
                        label = { Text("Reserva Operacional Padrao (%)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editMargem,
                        onValueChange = { editMargem = it },
                        label = { Text("Meta de Margem de Contribuicao (%)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editPrevisao,
                        onValueChange = { editPrevisao = it },
                        label = { Text("Previsao de Vendas Mensais (Lanches)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        }

        // CUSTOS FIXOS MENSAIS E RATEIO POR LANCHE
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("CUSTOS FIXOS MENSAIS", fontSize = 11.sp, fontWeight = FontWeight.Black, color = AmberBrand)
                        Text(
                            "Total: " + String.format(java.util.Locale.US, "R$ %.2f", totalCustosFixos),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = OrangeCmv
                        )
                    }

                    Text(
                        "Rateio fixo estimado: " + String.format(java.util.Locale.US, "R$ %.2f por lanche", rateioPorLanche),
                        fontSize = 11.sp,
                        color = TextMuted
                    )

                    custosFixos.forEach { cf ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CardSecondary, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(cf.nome, fontSize = 12.sp, color = Color.White)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(String.format(java.util.Locale.US, "R$ %.2f", cf.valor), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AmberBrand)
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(onClick = { onRemoverCustoFixo(cf.id) }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = null, tint = RedAlerta, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = novoCustoNome,
                            onValueChange = { novoCustoNome = it },
                            label = { Text("Nome (ex: Internet)") },
                            modifier = Modifier.weight(1.5f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = novoCustoValor,
                            onValueChange = { novoCustoValor = it },
                            label = { Text("Valor R$") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                val v = novoCustoValor.toDoubleOrNull() ?: 0.0
                                if (novoCustoNome.isNotBlank() && v > 0) {
                                    onAdicionarCustoFixo(novoCustoNome, v)
                                    novoCustoNome = ""
                                    novoCustoValor = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AmberBrand, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.align(Alignment.CenterVertically)
                        ) {
                            Text("+")
                        }
                    }
                }
            }
        }

        // BOTAO PRINCIPAL DE SALVAR
        item {
            Button(
                onClick = {
                    onSalvarNome(editNome)
                    onSalvarTaxaPix(editPix)
                    onSalvarTaxaDebito(editDeb)
                    onSalvarTaxaCredito(editCred)
                    onSalvarTaxaVoucher(editVoucher)
                    onSalvarReserva(editRes)
                    onSalvarMetaMargem(editMargem)
                    onSalvarPrevisaoLanches(editPrevisao)
                    salvoMsg = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = AmberBrand, contentColor = Color.Black),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text("SALVAR TODAS AS CONFIGURACOES", fontWeight = FontWeight.Black, fontSize = 13.sp)
            }
        }
    }
}
