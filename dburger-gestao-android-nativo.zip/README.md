# D’ Burger Gestão - Aplicativo Android Nativo Real

Aplicativo de gestão financeira e operacional para hamburguerias artesanais brasileiras.
Construído com **Kotlin**, **Jetpack Compose** e banco de dados local **Room SQLite**.

## 📱 Como Gerar o Arquivo APK Instalável no seu Celular

### Opção 1: Direto pelo Celular (Sem precisar de computador, 100% Grátis)
1. Crie uma conta no [GitHub](https://github.com).
2. Crie um novo repositório chamado `dburger-gestao`.
3. Envie os arquivos desta pasta para o repositório.
4. O GitHub Actions iniciará automaticamente o workflow `.github/workflows/build-apk.yml`.
5. Vá na aba **Actions**, clique na compilação concluída e baixe o artefato **dburger-gestao-debug-apk**.
6. Instale o arquivo `app-debug.apk` no seu Android!

### Opção 2: Pelo Computador com Android Studio
1. Baixe e instale o [Android Studio Hedgehog ou superior](https://developer.android.com/studio).
2. Abra o Android Studio e clique em **Open** (Abrir).
3. Selecione a pasta deste projeto descompactada.
4. Aguarde a sincronização do Gradle (leva cerca de 1 a 2 minutos).
5. No menu superior, clique em **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
6. O Android Studio gerará o APK na pasta `app/build/outputs/apk/debug/app-debug.apk`.
7. Conecte seu celular via USB ou envie o APK para o WhatsApp/Google Drive e instale!

## 🍔 Funcionalidades Nativas
- 100% Offline (Banco Room SQLite local).
- Fichas técnicas com recálculo automático de CMV.
- Baixa automática de ingredientes por lanche vendido.
- Separação real de Faturamento vs Reposição vs Reserva (12,1%) vs Caixa Livre.
