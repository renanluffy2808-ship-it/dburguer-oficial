package br.com.dburger.gestao.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AmberPrimary = Color(0xFFF59E0B)
val AmberDark = Color(0xFFB45309)
val ZincDark = Color(0xFF18181B)
val ZincBackground = Color(0xFF09090B)
val ZincSurface = Color(0xFF27272A)

private val DarkColorScheme = darkColorScheme(
    primary = AmberPrimary,
    secondary = AmberDark,
    background = ZincBackground,
    surface = ZincDark,
    surfaceVariant = ZincSurface,
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun DBurgerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
