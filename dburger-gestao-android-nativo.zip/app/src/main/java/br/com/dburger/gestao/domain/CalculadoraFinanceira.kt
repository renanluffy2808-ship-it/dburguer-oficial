package br.com.dburger.gestao.domain

import java.math.BigDecimal
import java.math.RoundingMode

object CalculadoraFinanceira {

    data class ParametrosPrecificacao(
        val cmv: BigDecimal,
        val custoFixoUnitario: BigDecimal,
        val taxaPagamentoPercent: BigDecimal,
        val reservaOperacionalPercent: BigDecimal,
        val margemAlvoPercent: BigDecimal,
        val precoVendaAtual: BigDecimal
    )

    data class ResultadoPrecificacao(
        val cmv: BigDecimal,
        val precoVendaAtual: BigDecimal,
        val markupAtual: BigDecimal,
        val margemBrutaPercent: BigDecimal,
        val taxaPagamentoValor: BigDecimal,
        val reservaOperacionalValor: BigDecimal,
        val saldoEstimadoUnitario: BigDecimal,
        val precoMinimo: BigDecimal,
        val precoRecomendado: BigDecimal,
        val statusCor: String, // VERDE, AMARELO, VERMELHO
        val motivoCor: String
    )

    /**
     * Fórmula: Preço = (C + F) / (1 - t - r - m)
     */
    fun calcularPrecificacao(params: ParametrosPrecificacao): ResultadoPrecificacao {
        val um = BigDecimal.ONE
        val cem = BigDecimal("100")

        val C = params.cmv
        val F = params.custoFixoUnitario
        val t = params.taxaPagamentoPercent.divide(cem, 4, RoundingMode.HALF_UP)
        val r = params.reservaOperacionalPercent.divide(cem, 4, RoundingMode.HALF_UP)
        val m = params.margemAlvoPercent.divide(cem, 4, RoundingMode.HALF_UP)
        val P = params.precoVendaAtual

        val markup = if (C > BigDecimal.ZERO) P.divide(C, 2, RoundingMode.HALF_UP) else BigDecimal.ZERO
        val margemBruta = if (P > BigDecimal.ZERO) {
            (P.subtract(C)).divide(P, 4, RoundingMode.HALF_UP).multiply(cem)
        } else BigDecimal.ZERO

        val taxaValor = P.multiply(t).setScale(2, RoundingMode.HALF_UP)
        val reservaValor = P.multiply(r).setScale(2, RoundingMode.HALF_UP)
        val saldoEstimado = P.subtract(C).subtract(taxaValor).subtract(reservaValor).subtract(F).setScale(2, RoundingMode.HALF_UP)

        // Denominador mínimo = 1 - t - r
        val denMin = um.subtract(t).subtract(r)
        val precoMinimo = if (denMin > BigDecimal("0.05")) {
            (C.add(F)).divide(denMin, 2, RoundingMode.HALF_UP)
        } else (C.add(F)).multiply(BigDecimal("1.5"))

        // Denominador com margem = 1 - t - r - m
        val denAlvo = um.subtract(t).subtract(r).subtract(m)
        val precoRecomendado = if (denAlvo > BigDecimal("0.05")) {
            (C.add(F)).divide(denAlvo, 2, RoundingMode.HALF_UP)
        } else (C.add(F)).multiply(BigDecimal("2.0"))

        var statusCor = "VERDE"
        var motivoCor = "Produto com margem saudável."

        if (C <= BigDecimal.ZERO) {
            statusCor = "VERMELHO"
            motivoCor = "Custo incompleto (CMV é zero)."
        } else if (P < precoMinimo) {
            statusCor = "VERMELHO"
            motivoCor = "Preço abaixo do mínimo necessário para cobrir custos."
        } else if (P < precoRecomendado) {
            statusCor = "AMARELO"
            motivoCor = "Preço abaixo da meta recomendada."
        }

        return ResultadoPrecificacao(
            cmv = C.setScale(2, RoundingMode.HALF_UP),
            precoVendaAtual = P.setScale(2, RoundingMode.HALF_UP),
            markupAtual = markup,
            margemBrutaPercent = margemBruta.setScale(2, RoundingMode.HALF_UP),
            taxaPagamentoValor = taxaValor,
            reservaOperacionalValor = reservaValor,
            saldoEstimadoUnitario = saldoEstimado,
            precoMinimo = precoMinimo,
            precoRecomendado = precoRecomendado,
            statusCor = statusCor,
            motivoCor = motivoCor
        )
    }

    /**
     * Custo Médio Ponderado (CMP)
     */
    fun calcularCustoMedioPonderado(
        qtdAtual: Double,
        custoAtual: Double,
        qtdComprada: Double,
        valorTotalCompra: Double
    ): Pair<Double, Double> {
        val totalQtd = qtdAtual + qtdComprada
        if (totalQtd <= 0.0) return Pair(0.0, custoAtual)
        val valorTotalEstoque = (qtdAtual * custoAtual) + valorTotalCompra
        val novoCusto = valorTotalEstoque / totalQtd
        return Pair(totalQtd, novoCusto)
    }
}
