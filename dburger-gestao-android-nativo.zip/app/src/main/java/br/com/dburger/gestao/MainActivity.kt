package br.com.dburger.gestao

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.dburger.gestao.ui.theme.DBurgerTheme

data class Insumo(
    val id: String,
    val nome: String,
    val categoria: String,
    var estoque: Double,
    val unidade: String,
    val custoUnitario: Double
)

data class ProdutoLanche(
    val id: String,
    val nome: String,
    val categoria: String,
    val preco: Double,
    val cmv: Double,
    val descricao: String
)

data class ItemCarrinho(
    val produto: ProdutoLanche,
    var quantidade: Int
)

data class VendaRegistro(
    val id: String,
    val numero: Int,
    val itensResumo: String,
    val valor: Double,
    val formaPagamento: String,
    val hora: String
)

data class Lancamento(
    val id: String,
    val tipo: String, // ENTRADA ou SAIDA
    val descricao: String,
    val valor: Double,
    val categoria: String,
    val hora: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DBurgerTheme {
                MainAppScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen() {
    var selectedTab by remember { mutableStateOf(0) }

    // Dados em memoria reativos
    val insumos = remember {
        mutableStateListOf(
            Insumo("1", "Blend Bovino Angus", "Carnes", 14.5, "kg", 38.00),
            Insumo("2", "Pao Brioche Artesanal", "Paes", 48.0, "un", 2.20),
            Insumo("3", "Queijo Cheddar Fatiado", "Queijos", 4.2, "kg", 45.00),
            Insumo("4", "Bacon em Tiras Defumado", "Carnes", 3.0, "kg", 52.00),
            Insumo("5", "Molho Especial D' Burger", "Molhos", 3.5, "L", 24.00),
            Insumo("6", "Embalagem Kraft Termica", "Embalagens", 85.0, "un", 1.15),
            Insumo("7", "Batata Congelada Palito", "Acompanhamentos", 8.0, "kg", 14.00),
            Insumo("8", "Coca-Cola Lata 350ml", "Bebidas", 42.0, "un", 2.80)
        )
    }

    val cardapio = remember {
        mutableStateListOf(
            ProdutoLanche("1", "D' Smash Duplo", "Smash", 28.00, 8.80, "2x Smash 80g, 2x Cheddar, Cebola e Pao Brioche"),
            ProdutoLanche("2", "D' Artesanal Bacon", "Artesanal", 34.00, 11.20, "Blend 160g, Cheddar, Bacon em tiras, Molho Especial"),
            ProdutoLanche("3", "X-Burguer Tradicional", "Simples", 22.00, 6.90, "Blend 120g, Queijo Prato derretido e Pao macio"),
            ProdutoLanche("4", "Combo D' Smash + Batata + Refri", "Combos", 44.00, 14.50, "Smash Duplo com porcao de Batata e Refrigerante lata"),
            ProdutoLanche("5", "Batata Frita Rustica", "Porcoes", 16.00, 4.50, "Batata frita crocante temperada com paprica")
        )
    }

    val vendas = remember {
        mutableStateListOf(
            VendaRegistro("1", 101, "2x D' Smash Duplo", 56.00, "Pix", "19:15"),
            VendaRegistro("2", 102, "1x D' Artesanal Bacon + Refri", 40.00, "Cartao Debito", "19:30"),
            VendaRegistro("3", 103, "1x Combo D' Smash", 44.00, "Dinheiro", "19:42")
        )
    }

    val lancamentos = remember {
        mutableStateListOf(
            Lancamento("1", "ENTRADA", "Venda Pedido #101", 56.00, "Venda", "19:15"),
            Lancamento("2", "ENTRADA", "Venda Pedido #102", 40.00, "Venda", "19:30"),
            Lancamento("3", "ENTRADA", "Venda Pedido #103", 44.00, "Venda", "19:42"),
            Lancamento("4", "SAIDA", "Gas de Cozinha Reserva", 110.00, "Despesa Fixa", "17:00")
        )
    }

    // Calculos Dinamicos
    val totalVendidoHoje = vendas.sumOf { it.valor }
    val totalBurguers = vendas.size * 2
    val totalCmv = totalVendidoHoje * 0.32
    val totalReservaOperacional = totalVendidoHoje * 0.121
    val saldoEmCaixa = lancamentos.sumOf { if (it.tipo == "ENTRADA") it.valor else -it.valor }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "D' Burger Gestao",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF59E0B)
                        )
                        Text(
                            text = "Hamburgueria Artesanal - Offline",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFA1A1AA)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF18181B)
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF18181B)) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Painel") },
                    label = { Text("Painel") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Menu, contentDescription = "Insumos") },
                    label = { Text("Insumos") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Star, contentDescription = "Cardapio") },
                    label = { Text("Cardapio") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Add, contentDescription = "PDV") },
                    label = { Text("PDV") }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Caixa") },
                    label = { Text("Caixa") }
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .background(Color(0xFF09090B))
        ) {
            when (selectedTab) {
                0 -> PainelScreen(
                    totalVendido = totalVendidoHoje,
                    burguersQtd = totalBurguers,
                    cmvValor = totalCmv,
                    reservaValor = totalReservaOperacional,
                    saldoCaixa = saldoEmCaixa,
                    onIrPdv = { selectedTab = 3 },
                    onIrInsumos = { selectedTab = 1 }
                )
                1 -> InsumosScreen(
                    insumos = insumos,
                    onAdicionarInsumo = { insumo -> insumos.add(insumo) },
                    onAlterarEstoque = { id, delta ->
                        val index = insumos.indexOfFirst { it.id == id }
                        if (index != -1) {
                            val item = insumos[index]
                            insumos[index] = item.copy(estoque = maxOf(0.0, item.estoque + delta))
                        }
                    }
                )
                2 -> CardapioScreen(
                    cardapio = cardapio,
                    onAdicionarLanche = { lanche -> cardapio.add(lanche) }
                )
                3 -> PdvScreen(
                    cardapio = cardapio,
                    insumos = insumos,
                    onFinalizarVenda = { itens, total, forma ->
                        val novoNumero = vendas.size + 101
                        val resumo = itens.joinToString(", ") { "${it.quantidade}x ${it.produto.nome}" }
                        vendas.add(0, VendaRegistro(System.currentTimeMillis().toString(), novoNumero, resumo, total, forma, "Agora"))
                        lancamentos.add(0, Lancamento(System.currentTimeMillis().toString(), "ENTRADA", "Venda Pedido #$novoNumero", total, "Venda", "Agora"))
                        
                        // Abater estoque simbolico de paes e carnes
                        val indexPao = insumos.indexOfFirst { it.categoria == "Paes" }
                        if (indexPao != -1) {
                            insumos[indexPao] = insumos[indexPao].copy(estoque = maxOf(0.0, insumos[indexPao].estoque - itens.sumOf { it.quantidade }))
                        }
                    }
                )
                4 -> CaixaScreen(
                    saldoTotal = saldoEmCaixa,
                    cmvAcumulado = totalCmv,
                    reservaOperacional = totalReservaOperacional,
                    lancamentos = lancamentos,
                    onRegistrarLancamento = { tipo, desc, valor, cat ->
                        lancamentos.add(0, Lancamento(System.currentTimeMillis().toString(), tipo, desc, valor, cat, "Hoje"))
                    }
                )
            }
        }
    }
}

// ---------------- TELAS COMPLETAS E INTERATIVAS ----------------

@Composable
fun PainelScreen(
    totalVendido: Double,
    burguersQtd: Int,
    cmvValor: Double,
    reservaValor: Double,
    saldoCaixa: Double,
    onIrPdv: () -> Unit,
    onIrInsumos: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18181B)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("SALDO ATUAL DISPONIVEL", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA1A1AA))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        String.format(java.util.Locale.US, "R$ %.2f", saldoCaixa),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = if (saldoCaixa >= 0) Color(0xFF10B981) else Color(0xFFEF4444)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Dinheiro real livre em caixa apos despesas", fontSize = 11.sp, color = Color(0xFF71717A))
                }
            }
        }

        item {
            Text("INDICADORES DE HOJE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B))
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DashboardMiniCard(
                    modifier = Modifier.weight(1f),
                    titulo = "FATURAMENTO",
                    valor = String.format(java.util.Locale.US, "R$ %.2f", totalVendido),
                    cor = Color(0xFF10B981)
                )
                DashboardMiniCard(
                    modifier = Modifier.weight(1f),
                    titulo = "LANCHES VENDIDOS",
                    valor = "$burguersQtd un",
                    cor = Color(0xFF38BDF8)
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DashboardMiniCard(
                    modifier = Modifier.weight(1f),
                    titulo = "CUSTO INSUMOS (CMV)",
                    valor = String.format(java.util.Locale.US, "R$ %.2f", cmvValor),
                    cor = Color(0xFFF97316)
                )
                DashboardMiniCard(
                    modifier = Modifier.weight(1f),
                    titulo = "RESERVA OP. (12,1%)",
                    valor = String.format(java.util.Locale.US, "R$ %.2f", reservaValor),
                    cor = Color(0xFFA855F7)
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            Button(
                onClick = onIrPdv,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color.Black),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("ABRIR FRENTE DE CAIXA (PDV)", fontWeight = FontWeight.Bold)
            }
        }

        item {
            OutlinedButton(
                onClick = onIrInsumos,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Icon(Icons.Default.Menu, contentDescription = null, tint = Color(0xFFF59E0B))
                Spacer(modifier = Modifier.width(8.dp))
                Text("VER ESTOQUE E INSUMOS")
            }
        }
    }
}

@Composable
fun DashboardMiniCard(modifier: Modifier = Modifier, titulo: String, valor: String, cor: Color) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF18181B)),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(titulo, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA1A1AA))
            Spacer(modifier = Modifier.height(6.dp))
            Text(valor, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = cor)
        }
    }
}

@Composable
fun InsumosScreen(
    insumos: List<Insumo>,
    onAdicionarInsumo: (Insumo) -> Unit,
    onAlterarEstoque: (String, Double) -> Unit
) {
    var mostrarDialogo by remember { mutableStateOf(false) }
    var nomeNovo by remember { mutableStateOf("") }
    var categoriaNova by remember { mutableStateOf("Carnes") }
    var estoqueNovo by remember { mutableStateOf("10.0") }
    var unidadeNova by remember { mutableStateOf("kg") }
    var custoNovo by remember { mutableStateOf("35.00") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Estoque de Insumos", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Gerencie ingredientes e embalagens", fontSize = 11.sp, color = Color(0xFFA1A1AA))
                }
                Button(
                    onClick = { mostrarDialogo = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Novo", fontWeight = FontWeight.Bold)
                }
            }
        }

        items(insumos) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18181B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.nome, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        Text(
                            "${item.categoria} • Custo: R$ " + String.format(java.util.Locale.US, "%.2f", item.custoUnitario) + "/${item.unidade}",
                            fontSize = 11.sp,
                            color = Color(0xFFA1A1AA)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { onAlterarEstoque(item.id, -1.0) },
                            modifier = Modifier.size(32.dp).background(Color(0xFF27272A), RoundedCornerShape(8.dp))
                        ) {
                            Text("-", color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        Text(
                            text = String.format(java.util.Locale.US, "%.1f %s", item.estoque, item.unidade),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (item.estoque > 5.0) Color(0xFF10B981) else Color(0xFFEF4444),
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        IconButton(
                            onClick = { onAlterarEstoque(item.id, 1.0) },
                            modifier = Modifier.size(32.dp).background(Color(0xFF27272A), RoundedCornerShape(8.dp))
                        ) {
                            Text("+", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (mostrarDialogo) {
        AlertDialog(
            onDismissRequest = { mostrarDialogo = false },
            title = { Text("Cadastrar Novo Insumo") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = nomeNovo,
                        onValueChange = { nomeNovo = it },
                        label = { Text("Nome do Insumo") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = estoqueNovo,
                        onValueChange = { estoqueNovo = it },
                        label = { Text("Estoque Inicial (numero)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = custoNovo,
                        onValueChange = { custoNovo = it },
                        label = { Text("Custo por Unidade (R$)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (nomeNovo.isNotBlank()) {
                        val est = estoqueNovo.toDoubleOrNull() ?: 10.0
                        val cus = custoNovo.toDoubleOrNull() ?: 20.0
                        onAdicionarInsumo(
                            Insumo(System.currentTimeMillis().toString(), nomeNovo, categoriaNova, est, unidadeNova, cus)
                        )
                        mostrarDialogo = false
                        nomeNovo = ""
                    }
                }) {
                    Text("Salvar")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarDialogo = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun CardapioScreen(
    cardapio: List<ProdutoLanche>,
    onAdicionarLanche: (ProdutoLanche) -> Unit
) {
    var mostrarModal by remember { mutableStateOf(false) }
    var nomeLanche by remember { mutableStateOf("") }
    var categoriaLanche by remember { mutableStateOf("Artesanal") }
    var precoLanche by remember { mutableStateOf("30.00") }
    var cmvLanche by remember { mutableStateOf("9.50") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Cardapio e Fichas", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Precos de venda, CMV e margem", fontSize = 11.sp, color = Color(0xFFA1A1AA))
                }
                Button(
                    onClick = { mostrarModal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Novo Lanche", fontWeight = FontWeight.Bold)
                }
            }
        }

        items(cardapio) { lanche ->
            val margemBruta = if (lanche.preco > 0) ((lanche.preco - lanche.cmv) / lanche.preco) * 100.0 else 0.0

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18181B)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(lanche.nome, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                            Text(lanche.descricao, fontSize = 11.sp, color = Color(0xFFA1A1AA))
                        }
                        Text(
                            String.format(java.util.Locale.US, "R$ %.2f", lanche.preco),
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = Color(0xFFF59E0B)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().background(Color(0xFF27272A), RoundedCornerShape(8.dp)).padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "CMV: " + String.format(java.util.Locale.US, "R$ %.2f", lanche.cmv),
                            fontSize = 11.sp,
                            color = Color(0xFFF97316),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Margem Bruta: " + String.format(java.util.Locale.US, "%.1f%%", margemBruta),
                            fontSize = 11.sp,
                            color = Color(0xFF10B981),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    if (mostrarModal) {
        AlertDialog(
            onDismissRequest = { mostrarModal = false },
            title = { Text("Novo Item no Cardapio") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = nomeLanche,
                        onValueChange = { nomeLanche = it },
                        label = { Text("Nome do Lanche") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = precoLanche,
                        onValueChange = { precoLanche = it },
                        label = { Text("Preco de Venda (R$)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = cmvLanche,
                        onValueChange = { cmvLanche = it },
                        label = { Text("Custo Total Ingredientes (R$)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (nomeLanche.isNotBlank()) {
                        val p = precoLanche.toDoubleOrNull() ?: 25.0
                        val c = cmvLanche.toDoubleOrNull() ?: 8.0
                        onAdicionarLanche(
                            ProdutoLanche(System.currentTimeMillis().toString(), nomeLanche, categoriaLanche, p, c, "Feito na chapa artesanal")
                        )
                        mostrarModal = false
                        nomeLanche = ""
                    }
                }) {
                    Text("Cadastrar")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModal = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun PdvScreen(
    cardapio: List<ProdutoLanche>,
    insumos: List<Insumo>,
    onFinalizarVenda: (List<ItemCarrinho>, Double, String) -> Unit
) {
    val carrinho = remember { mutableStateListOf<ItemCarrinho>() }
    var formaPagamento by remember { mutableStateOf("Pix") }
    var vendaConcluidaMsg by remember { mutableStateOf<String?>(null) }

    val totalPedido = carrinho.sumOf { it.produto.preco * it.quantidade }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("PDV - Ponto de Venda Rapido", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Selecione os lanches vendidos na chapa", fontSize = 11.sp, color = Color(0xFFA1A1AA))
        }

        if (vendaConcluidaMsg != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF065F46)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF34D399))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(vendaConcluidaMsg ?: "", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text("CARDAPIO", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B))
        }

        items(cardapio) { lanche ->
            val itemNoCarrinho = carrinho.find { it.produto.id == lanche.id }
            val qtd = itemNoCarrinho?.quantidade ?: 0

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18181B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(lanche.nome, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Text(String.format(java.util.Locale.US, "R$ %.2f", lanche.preco), color = Color(0xFFF59E0B), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (qtd > 0) {
                            IconButton(
                                onClick = {
                                    val index = carrinho.indexOfFirst { it.produto.id == lanche.id }
                                    if (index != -1) {
                                        if (carrinho[index].quantidade > 1) {
                                            carrinho[index] = carrinho[index].copy(quantidade = carrinho[index].quantidade - 1)
                                        } else {
                                            carrinho.removeAt(index)
                                        }
                                    }
                                },
                                modifier = Modifier.size(32.dp).background(Color(0xFF27272A), RoundedCornerShape(8.dp))
                            ) {
                                Text("-", color = Color.White, fontWeight = FontWeight.Bold)
                            }

                            Text("$qtd", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                        }

                        Button(
                            onClick = {
                                val index = carrinho.indexOfFirst { it.produto.id == lanche.id }
                                if (index != -1) {
                                    carrinho[index] = carrinho[index].copy(quantidade = carrinho[index].quantidade + 1)
                                } else {
                                    carrinho.add(ItemCarrinho(lanche, 1))
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(if (qtd > 0) "+1" else "Adicionar", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (carrinho.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF27272A)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("RESUMO DO PEDIDO", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFA1A1AA))
                        Spacer(modifier = Modifier.height(6.dp))

                        carrinho.forEach {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${it.quantidade}x ${it.produto.nome}", fontSize = 12.sp, color = Color.White)
                                Text(String.format(java.util.Locale.US, "R$ %.2f", it.produto.preco * it.quantidade), fontSize = 12.sp, color = Color.White)
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFF3F3F46))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("TOTAL A COBRAR:", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                            Text(String.format(java.util.Locale.US, "R$ %.2f", totalPedido), fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color(0xFF10B981))
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Forma de Pagamento:", fontSize = 11.sp, color = Color(0xFFA1A1AA))
                        Spacer(modifier = Modifier.height(4.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Pix", "Dinheiro", "Debito", "Credito").forEach { forma ->
                                FilterChip(
                                    selected = formaPagamento == forma,
                                    onClick = { formaPagamento = forma },
                                    label = { Text(forma, fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFF59E0B),
                                        selectedLabelColor = Color.Black
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                onFinalizarVenda(carrinho.toList(), totalPedido, formaPagamento)
                                vendaConcluidaMsg = "Pedido de " + String.format(java.util.Locale.US, "R$ %.2f", totalPedido) + " no " + formaPagamento + " concluido com sucesso!"
                                carrinho.clear()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.Black),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Text("CONFIRMAR VENDA E DAR BAIXA", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CaixaScreen(
    saldoTotal: Double,
    cmvAcumulado: Double,
    reservaOperacional: Double,
    lancamentos: List<Lancamento>,
    onRegistrarLancamento: (String, String, Double, String) -> Unit
) {
    var mostrarModalEntrada by remember { mutableStateOf(false) }
    var descLancamento by remember { mutableStateOf("") }
    var valorLancamento by remember { mutableStateOf("") }
    var tipoLancamento by remember { mutableStateOf("SAIDA") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Fluxo de Caixa e Destinacao", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Separacao correta das gavetas financeiras", fontSize = 11.sp, color = Color(0xFFA1A1AA))
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18181B)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("SALDO TOTAL EM CAIXA", fontSize = 11.sp, color = Color(0xFFA1A1AA), fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        String.format(java.util.Locale.US, "R$ %.2f", saldoTotal),
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFF59E0B)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = Color(0xFF27272A))
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Divisao Inteligente do Dinheiro:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Gaveta 1: Reposicao de Insumos", fontSize = 11.sp, color = Color(0xFFA1A1AA))
                        Text(String.format(java.util.Locale.US, "R$ %.2f", cmvAcumulado), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF97316))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Gaveta 2: Reserva Operacional (12,1%)", fontSize = 11.sp, color = Color(0xFFA1A1AA))
                        Text(String.format(java.util.Locale.US, "R$ %.2f", reservaOperacional), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA855F7))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Gaveta 3: Lucro Livre do Proprietario", fontSize = 11.sp, color = Color(0xFFA1A1AA))
                        val lucroLivre = maxOf(0.0, saldoTotal - cmvAcumulado - reservaOperacional)
                        Text(String.format(java.util.Locale.US, "R$ %.2f", lucroLivre), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                    }
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        tipoLancamento = "SAIDA"
                        mostrarModalEntrada = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444), contentColor = Color.White),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("- Despesa / Retirada", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        tipoLancamento = "ENTRADA"
                        mostrarModalEntrada = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("+ Entrada Caixa", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Text("LANCAMENTOS RECENTES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B))
        }

        items(lancamentos) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18181B)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(item.descricao, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("${item.categoria} • ${item.hora}", fontSize = 11.sp, color = Color(0xFFA1A1AA))
                    }
                    Text(
                        text = (if (item.tipo == "ENTRADA") "+ " else "- ") + String.format(java.util.Locale.US, "R$ %.2f", item.valor),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (item.tipo == "ENTRADA") Color(0xFF10B981) else Color(0xFFEF4444)
                    )
                }
            }
        }
    }

    if (mostrarModalEntrada) {
        AlertDialog(
            onDismissRequest = { mostrarModalEntrada = false },
            title = { Text(if (tipoLancamento == "ENTRADA") "Adicionar Entrada no Caixa" else "Registrar Despesa / Retirada") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = descLancamento,
                        onValueChange = { descLancamento = it },
                        label = { Text("Descricao (ex: Compra de Queijo, Gas, Retirada)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = valorLancamento,
                        onValueChange = { valorLancamento = it },
                        label = { Text("Valor em Reais (R$)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val v = valorLancamento.toDoubleOrNull() ?: 0.0
                    if (descLancamento.isNotBlank() && v > 0) {
                        onRegistrarLancamento(tipoLancamento, descLancamento, v, if (tipoLancamento == "ENTRADA") "Aporte" else "Despesa")
                        mostrarModalEntrada = false
                        descLancamento = ""
                        valorLancamento = ""
                    }
                }) {
                    Text("Confirmar")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarModalEntrada = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}
