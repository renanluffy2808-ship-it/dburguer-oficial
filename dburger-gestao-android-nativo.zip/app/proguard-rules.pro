# ProGuard rules for D' Burger Gestao
-keepattributes *Annotation*
-dontwarn java.math.**
-dontwarn br.com.dburger.gestao.**
